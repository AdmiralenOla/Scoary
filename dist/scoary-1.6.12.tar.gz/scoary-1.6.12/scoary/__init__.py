__version__ = '1.6.12'
__author__ = 'Ola Brynildsrud'
__credits__ = ['Ola Brynildsrud']
__license__ = 'GPL3'
__maintainer__ = 'Ola Brynildsrud'
__email__ = 'olbb@fhi.no'
